// Analyze Safe proposals and track most active signers
