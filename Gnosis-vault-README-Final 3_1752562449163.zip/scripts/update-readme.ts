// Script to update Safe balances and inject into README
