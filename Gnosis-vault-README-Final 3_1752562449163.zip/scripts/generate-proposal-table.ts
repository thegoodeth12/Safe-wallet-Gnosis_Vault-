// Pull proposals from Safe API and format for README table
