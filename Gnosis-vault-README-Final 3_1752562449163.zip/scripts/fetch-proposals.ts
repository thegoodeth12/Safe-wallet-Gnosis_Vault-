// Script to fetch Safe proposals and format markdown table
